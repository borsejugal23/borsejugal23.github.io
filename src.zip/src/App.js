import './App.css';
import { AboutSection } from './components/About';
import { HeroSection } from './components/Hero';
import { Navbar } from './components/Navbar';
import { SkillsSection } from './components/SkillSection';


function App() {
  return (
    <div className="App">
    <Navbar/>
    <HeroSection/>
    <AboutSection/>
    <SkillsSection/>
    </div>
  );
}

export default App;
