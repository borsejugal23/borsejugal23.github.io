import styles from "../Styles/Navbar.module.css"
import { Link } from "react-scroll"
// import {Link} from "react-router-dom"
export function Navbar() {
  return (
    <div className={styles.root} id="nav-menu">
      <Link
        to="home"
        smooth={true}
        duration={1000}
        spy={true}
        hashSpy={true}
        activeClass={styles.active}
        className="nav-link home"
      >
        <div className={styles.navlogo}>
          <img src="/logo.jpg" alt="" className={styles.logoimg} />
        </div>
      </Link>
      <div className={styles.navsCont}>
        <Link
          to="about"
          smooth={true}
          duration={1000}
          activeClass={styles.active}
          spy={true}
          hashSpy={true}
          className="nav-link about"
        >
          <div className={styles.nav}>About</div>
        </Link>
        <Link
          to="skills"
          smooth={true}
          duration={1000}
          activeClass={styles.active}
          spy={true}
          hashSpy={true}
          className="nav-link skills"
        >
          <div className={styles.nav}>Skills</div>
        </Link>
        <Link
          to="projects"
          smooth={true}
          duration={1000}
          activeClass={styles.active}
          spy={true}
          hashSpy={true}
          className="nav-link projects"
        >
          <div className={styles.nav}>Projects</div>
        </Link>
        <Link
          to="contact"
          smooth={true}
          duration={1000}
          activeClass={styles.active}
          spy={true}
          hashSpy={true}
          className="nav-link contact"
        >
          <div className={styles.nav}>Contact</div>
        </Link>
      </div>
    </div>
  )
}
